﻿namespace Sparcpoint.SqlServer.Abstractions
{
    public class SqlServerOptions : ISqlServerOptions
    {
        public string ConnectionString { get; set; }
    }
}
