﻿namespace Sparcpoint.SqlServer.Abstractions
{
    public interface ISqlServerOptions
    {
        string ConnectionString { get; set; }
    }
}