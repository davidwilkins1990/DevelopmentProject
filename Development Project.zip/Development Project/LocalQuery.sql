﻿  
SELECT * FROM Instances.Products

SELECT * FROM Instances.ProductCategories

SELECT * FROM Instances.ProductAttributes

SELECT * FROM Instances.Categories

SELECT * FROM Instances.CategoryAttributes

--SELECT * FROM Instances.CategoryCategories

SELECT * FROM [Sparcpoint.Inventory.Database].Transactions.InventoryTransactions

/*
-Inventory name should be unique
ALTER TABLE Instances.Products ADD CONSTRAINT UniqueName UNIQUE (Name);

*/

	--INSERT a few initial products 
/*
INSERT INTO Instances.Products
(Name, Description, ProductImageUris, ValidSkus, CreatedTimestamp)
VALUES
	('Pen', 'Writing Pen by Signo', '/images/product.png', 'PEN123', SYSUTCDATETIME()),
	('Skittles', 'Hard candy original flavors', '/images/product.png', 'CANDY123', SYSUTCDATETIME()),
	('Reeses Pieces', 'Chocolate and peanut butter candy pieces', '/images/product.png', 'CANDY223', SYSUTCDATETIME())



INSERT INTO Instances.Categories
VALUES
	('Supplies', 'Various supplies for office use', SYSUTCDATETIME()),
	('Candy', 'Various candys and chocolates', SYSUTCDATETIME())
	

INSERT INTO Instances.ProductCategories
VALUES
	(1,1), (2,2), (3,2)


INSERT INTO Instances.ProductAttributes
VALUES
	(1, 'Color','Black'),
	(1, 'Style','Click'),
	(1, 'Point','Fine Point 0.7mm'),
	(2, 'Size','Small'),
	(3, 'Size','Large')

INSERT INTO Instances.CategoryAttributes
VALUES
	(1,'Consumable','FALSE'),
	(1,'RecurringOrder','TRUE'),
	(2,'Consumable','TRUE')

	--INSERT a few initial transactions


INSERT INTO Transactions.InventoryTransactions
VALUES
(1, 10, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(1, -8, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Subtract'),
(1, 12, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(1, 5, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(1, -11, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Subtract'),
(1, 14, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(2, 25, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(2, 7, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add'),
(2, -16, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Subtract'),
(2, 10, SYSUTCDATETIME(), DATEADD(MINUTE, 2, SYSUTCDATETIME()) , 'Add')

-- Stored Procedure for adding product

CREATE PROCEDURE Instances.spAddProduct
@Name VARCHAR(256) = '',
@Description VARCHAR(256) = '',
@ProductImageUris VARCHAR(MAX) = '',
@ValidSkus VARCHAR(MAX) = '',
@CategoryId INT = 0,
@AttributeKey VARCHAR(64) = '',
@AttribueValue VARCHAR(512) = ''

AS
BEGIN
	INSERT INTO Instances.Products
	VALUES
	(
		@Name,
		@Description,
		@ProductImageUris,
		@ValidSkus,
		SYSUTCDATETIME()
	)

	IF @CategoryId > 0
	BEGIN	
		INSERT INTO Instances.ProductCategories
		VALUES
		(
			(SELECT InstanceId FROM Instances.Products p WHERE p.Name = @Name),
			@CategoryId
		)
	END

	IF @AttributeKey != '' AND @AttribueValue != ''
	BEGIN
		INSERT INTO Instances.ProductAttributes
		VALUES
		(
			(SELECT InstanceId FROM Instances.Products p WHERE p.Name = @Name),
			@AttributeKey,
			@AttribueValue
		)
	END
END

EXEC Instances.spAddProduct 
	@Name = 'Bottled Water',
	@Description = 'Bottle water for office use',
	@ProductImageUris = '/images/product.png',
	@ValidSkus = 'WATER123',
	@CategoryId = 1,
	@AttributeKey = 'Size',
	@AttribueValue = '16.9oz'

SELECT * FROM Instances.Products
SELECT * FROM Instances.ProductCategories
SELECT * FROM Instances.ProductAttributes

*/
-- Stored procedure for adding/removing transactions , and some sample data
/*
CREATE PROCEDURE Transactions.spTransaction
@TransactionId INT = 0,
@ProductInstanceId INT = 0,
@Quantity DECIMAL(19,6) = 0.0,
@TypeCategory VARCHAR(32) = '',
@DeleteTransaction BIT = 0
AS
BEGIN
	IF @TransactionId > 0 AND @DeleteTransaction = 1
		BEGIN
			DELETE FROM Transactions.InventoryTransactions WHERE TransactionId = @TransactionId
		END
	ELSE IF @ProductInstanceId > 0 
		BEGIN
			INSERT INTO Transactions.InventoryTransactions
			VALUES
			(
				@ProductInstanceId,
				@Quantity,
				SYSUTCDATETIME(),
				DATEADD(SECOND, 2, SYSUTCDATETIME()),
				@TypeCategory
			)
		END
END
/*
EXEC Transactions.spTransaction
@TransactionId = 0,
@ProductInstanceId =6,
@Quantity = 12,
@TypeCategory = 'Add',
@DeleteTransaction = 0

EXEC Transactions.spTransaction
@TransactionId = 0,
@ProductInstanceId =6,
@Quantity = -4,
@TypeCategory = 'Subtract',
@DeleteTransaction = 0

EXEC Transactions.spTransaction
@TransactionId = 13,
@DeleteTransaction = 1

SELECT * FROM Transactions.InventoryTransactions
*/

*/

-- Todo-Wilkins: need to add scripts to add more categories/attributes for each item

/*
Views to join some data


CREATE VIEW [Transactions].[vwTransactions]

AS
	SELECT TOP 100 PERCENT 
		p.[Name] AS 'Product',
		t.*,
		SUM(Quantity) OVER (PARTITION BY p.[Name] ORDER BY TransactionId) AS 'RunningTotal'
	FROM
		Transactions.InventoryTransactions t
		LEFT JOIN Instances.Products p ON p.InstanceId = t.ProductInstanceId
	ORDER BY
		StartedTimestamp ASC



*/

/*


CREATE VIEW [Instances].[vwProducts]
AS

SELECT 
	p.InstanceId AS 'Id',
	p.[Name] AS 'Product',
	p.[Description],
	p.[ProductImageUris] AS 'Image',
	p.[ValidSkus] AS 'SKU',

	c.[Name] AS 'Category',
	c.[Description] AS 'CategoryDescription',
	--pa.[Key] AS 'Attribute',
	--pa.[Value] AS 'Value',
	(SELECT Attributes = STUFF((
         SELECT CHAR(10) + [Key] + ': ' + [Value] 
            FROM Instances.ProductAttributes pa WHERE pa.InstanceId = p.InstanceId
            FOR XML PATH('')
         ), 1, 1, '')) AS 'Attributes',		 
	(SELECT ISNULL(SUM(ISNULL(Quantity, 0.0)), 0.000000) FROM Transactions.InventoryTransactions t WHERE t.ProductInstanceId = p.InstanceId) AS 'Quantity',
	p.CreatedTimestamp AS 'Created'
FROM
	Instances.Products p
	LEFT JOIN Instances.ProductCategories pc ON pc.InstanceId = p.InstanceId
	LEFT JOIN Instances.Categories c ON c.InstanceId = pc.CategoryInstanceId
	
*/