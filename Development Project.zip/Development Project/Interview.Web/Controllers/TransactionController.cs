﻿using Interview.Web.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sparcpoint.SqlServer.Abstractions;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Interview.Web.Controllers
{
    [Route("api/v1/transactions")]

    public class TransactionController : Controller
    {

        public ISqlServerOptions SqlOptions { get; set; }
        public ISqlExecutor SqlExecutor { get; set; }
        public TransactionController(ISqlServerOptions sqlOptions)
        {
            SqlOptions = sqlOptions;
            SqlExecutor = new SqlServerExecutor(SqlOptions.ConnectionString);
        }

    
        [HttpGet]
        public Task<IActionResult> Get()
        {
            DataTable table = new DataTable();

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand("SELECT * FROM Transactions.vwTransactions", sqlConn);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.Clear();
                using (var sqlReader = sqlCommand.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        table.Load(sqlReader);
                    }
                }
            }

            string json = string.Empty;
            json = JsonConvert.SerializeObject(table);

            return Task.FromResult((IActionResult)Ok(json));
        }

        
        [IgnoreAntiforgeryToken]
        [HttpPost]
        public Task<IActionResult> PostTransaction([FromBody] TransactionDto transaction)
        {
            /*
             * @TransactionId INT = 0,
                @ProductInstanceId INT = 0,
                @Quantity DECIMAL(19,6) = 0.0,
                @TypeCategory VARCHAR(32) = '',
                @DeleteTransaction BIT = 0
            */

            if (transaction == null)
            {
                return Task.FromResult((IActionResult)BadRequest("Invalid Data"));
            }

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand("Transactions.spTransaction", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@TransactionId", transaction.TransactionId ?? 0);
                sqlCommand.Parameters.AddWithValue("@ProductInstanceId", transaction.ProductInstanceId);
                sqlCommand.Parameters.AddWithValue("@Quantity", transaction.Quantity);
                sqlCommand.Parameters.AddWithValue("@TypeCategory", transaction.TypeCategory);
                sqlCommand.Parameters.AddWithValue("@DeleteTransaction", transaction.Delete ?? false);

                //execute query, returns number of rows affected 
                int i = sqlCommand.ExecuteNonQuery();
            }


            string json = string.Empty;
            json = JsonConvert.SerializeObject(transaction);

            return Task.FromResult((IActionResult)Ok(json));
        }
    }
}
