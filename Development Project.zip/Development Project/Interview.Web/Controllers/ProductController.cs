﻿using Interview.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sparcpoint.SqlServer.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Interview.Web.Controllers
{
    /*
     
    I had trouble understanding how to implement the SqlExecutor that was provided, so I used another method.

    
     
     */

    [Route("api/v1/products")]
    public class ProductController : Controller
    {
        public ISqlServerOptions SqlOptions { get; set; }
        public ISqlExecutor SqlExecutor { get; set; }
        public ProductController(ISqlServerOptions sqlOptions)
        {
            SqlOptions = sqlOptions;
            SqlExecutor = new SqlServerExecutor(SqlOptions.ConnectionString);
        }

        [HttpGet]
        public Task<IActionResult> Get()
        {
            //TransactionSqlServerExecutor transaction = new TransactionSqlServerExecutor();
            DataTable table = new DataTable();

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand("SELECT * FROM Instances.vwProducts", sqlConn);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.Clear();
                using (var sqlReader = sqlCommand.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        table.Load(sqlReader);
                    }
                }
            }

            string json = string.Empty;
            json = JsonConvert.SerializeObject(table);

            return Task.FromResult((IActionResult)Ok(json));
        }

        /*
            Need to be able to search by user critera : category, attributes, categoyAttrbitues

            
         */


        [HttpGet("{id}")]
        public Task<IActionResult> Get(int id = 0, int[] categories = null, string[] attributeKeys = null)
   
        {
            DataTable table = new DataTable();

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConn;

                if (id > 0)
                {
                    sqlCommand.CommandText = $@"
                                SELECT * FROM Instances.Products
                                WHERE InstanceId = {id}
                                ";
                }
                else if (categories != null && categories.Length > 0)
                {
                    string category = string.Join(",", categories);

                    sqlCommand.CommandText = $@"
                                SELECT * FROM Instances.Products
                                WHERE 
                                    InstanceId IN (
                                                    SELECT InstanceId 
                                                    FROM Instances.ProductCategories 
                                                    WHERE CategoryInstanceId IN {category}
                                                  )
                                ";
                }
                else if (attributeKeys != null && attributeKeys.Length > 0)
                {
                    string attrKeys = string.Join(",", attributeKeys);

                    sqlCommand.CommandText = $@"
                                SELECT * FROM Instances.Products
                                WHERE 
                                    InstanceId IN (
                                                    SELECT InstanceId 
                                                    FROM Instances.ProductAttributes 
                                                    WHERE Key IN {attrKeys}
                                                  )
                                ";
                }
                else
                {
                    return Task.FromResult((IActionResult)BadRequest("Invalid Data"));
                }


                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.Clear();
                using (var sqlReader = sqlCommand.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        table.Load(sqlReader);
                    }
                }
            }

            string json = string.Empty;
            json = JsonConvert.SerializeObject(table);

            return Task.FromResult((IActionResult)Ok(json));
          
        }


        [HttpPost("{counts}")]
        public Task<IActionResult> Counts(string request)
        {
            DataTable table = new DataTable();

            int[] ids = new int[2] { 1,2};

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConn;

                if (ids == null)
                {
                    return Task.FromResult((IActionResult)BadRequest("Invalid Data"));

                }
                string category = string.Join(",", ids);

                sqlCommand.CommandText = $@"
                            SELECT * FROM Instances.Products
                            WHERE 
                                InstanceId IN (
                                                SELECT InstanceId 
                                                FROM Instances.ProductCategories 
                                                WHERE CategoryInstanceId IN {category}
                                                )
                            ";



                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.Clear();
                using (var sqlReader = sqlCommand.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        table.Load(sqlReader);
                    }
                }
            }

            string json = string.Empty;
            json = JsonConvert.SerializeObject(table);

            return Task.FromResult((IActionResult)Ok(json));
        }

        [IgnoreAntiforgeryToken]
        [HttpPost]
        public Task<IActionResult> PostProduct([FromBody] ProductDto product)
        {

            /*             
                @Name = 'Bottled Water',
	            @Description = 'Bottle water for office use',
	            @ProductImageUris = '/images/product.png',
	            @ValidSkus = 'WATER123',
	            @CategoryId = 1,
	            @AttributeKey = 'Size',
	            @AttributeValue = '16.9oz'
            */
            
            if (product == null)
            {
                return Task.FromResult((IActionResult)BadRequest("Invalid Data"));
            }
            //ProductDto product = new ProductDto();
            //product = (ProductDto)JsonConvert.DeserializeObject(productJson, typeof(ProductDto));

            using (var sqlConn = new SqlConnection(SqlOptions.ConnectionString))
            {
                sqlConn.Open();
                var sqlCommand = new SqlCommand("Instances.spAddProduct", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Name", product.Name);
                sqlCommand.Parameters.AddWithValue("@Description", product.Description);
                sqlCommand.Parameters.AddWithValue("@ProductImageUris", product.ProductImageUris);
                sqlCommand.Parameters.AddWithValue("@ValidSkus", product.ValidSkus);
                sqlCommand.Parameters.AddWithValue("@CategoryId", product.CategoryInstanceId);
                sqlCommand.Parameters.AddWithValue("@AttributeKey", product.AttributeKey);
                sqlCommand.Parameters.AddWithValue("@AttributeValue", product.AttributeValue);

                //execute query, returns number of rows affected 
                int i = sqlCommand.ExecuteNonQuery();
            }

            string json = string.Empty;
            json = JsonConvert.SerializeObject(product);

            return Task.FromResult((IActionResult)Ok(json));
        }              
    }
}
