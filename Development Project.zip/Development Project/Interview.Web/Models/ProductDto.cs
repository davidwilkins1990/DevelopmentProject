﻿using System.Collections.Generic;

namespace Interview.Web.Models
{
    public class ProductDto
    {
        public int? InstanceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ProductImageUris { get; set; }
        public string ValidSkus { get; set; }
        public int CategoryInstanceId { get; set; }
        public string AttributeKey { get; set; }
        public string AttributeValue { get; set; }


        public ProductDto()
        {

        }

        public ProductDto(int? instanceId, string name, string description, string productImageUris, string validSkus, int categoryId, string attributeKey, string attributeValue)
        {
            InstanceId = instanceId;    
            Name = name;
            Description = description;
            ProductImageUris = productImageUris;
            ValidSkus = validSkus;
            CategoryInstanceId = categoryId;
            AttributeKey = attributeKey;
            AttributeValue = attributeValue;                                
        }
    }

}
