﻿using Interview.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MvcTest.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sparcpoint.SqlServer.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace MvcTest.Controllers
{
    public class InventoryController : Controller
    {
        private readonly ILogger<InventoryController> _logger;    
        public InventoryController(ILogger<InventoryController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        //[IgnoreAntiforgeryToken]
        public async Task<IActionResult> OnPostMakeRequest(string requestURL)
        {
            var json = MakeRequest(requestURL);

            return new JsonResult(json);
        }

        

        public List<ProductDto> MakeRequest(string requestUrl, int id = 0)
        {
            string EndPoint = requestUrl;

            List<ProductDto> productList = new List<ProductDto>();
            
            string responseValue = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EndPoint);              
            
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                // check the return status (200 is OK)
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("Bad response - " + response.StatusCode);
                }

                // Process 
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            responseValue = reader.ReadToEnd();

                        }
                    }
                } 
            } // end using respone

            // parse into jObject
            //JObject jResponse = JObject.Parse(responseValue);
            JArray jResponse = JArray.Parse(responseValue);



            // map jObject to desired object
            foreach (var product in jResponse)
            {
                var add = product.ToObject<ProductDto>();

                productList.Add(add);
            }


            if (productList.Count == 0)
            {
                ProductDto mock = new ProductDto(1, "mock", "mock product", "/img", "SKU123", 1, "Brand", "Fake");
                productList.Add(mock);
            }

            return productList;
        }

        public ActionResult Products(string requestUrl)
        {
            if (string.IsNullOrEmpty(requestUrl))
            {
                requestUrl = "https://localhost:44387/api/v1/products";
            }

            string EndPoint = requestUrl;          
            string responseValue = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EndPoint);

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                // check the return status (200 is OK)
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("Bad response - " + response.StatusCode);
                }

                // Process 
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            responseValue = reader.ReadToEnd();
                        }
                    }
                }
            } // end using respone

            Table model = new Table();
            model.ResultTable = (DataTable)JsonConvert.DeserializeObject(responseValue, (typeof(DataTable)));
            return View("Products", model);
        }

        public ActionResult Transactions(string requestUrl)
        {
            if (string.IsNullOrEmpty(requestUrl))
            {
                requestUrl = "https://localhost:44387/api/v1/transactions";
            }

            string EndPoint = requestUrl;
            string responseValue = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EndPoint);

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                // check the return status (200 is OK)
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("Bad response - " + response.StatusCode);
                }

                // Process 
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            responseValue = reader.ReadToEnd();
                        }
                    }
                }
            } // end using respone

            Table model = new Table();
            model.ResultTable = (DataTable)JsonConvert.DeserializeObject(responseValue, (typeof(DataTable)));
            return View("Transactions", model);
        }

        public ActionResult ProductInfo(int Id = 0)
        {
            if (Id == 0)
            {
                return RedirectToAction("Products");
            }
            else
            {                                
                return View();
            }
        }

        [IgnoreAntiforgeryToken]
        public ActionResult Create(ProductDto product)
        {
            
            string json = JsonConvert.SerializeObject(product);
                           
            string EndPoint = "https://localhost:44387/api/v1/products/create";

            // Test POST syntax
            //EndPoint = "https://webhook.site/02ff76b8-f8fa-42c3-86bc-900241b69ee2";
            HttpClient client = new HttpClient();

            string responseValue = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EndPoint);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Accept = "application/json";

            using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
            {
                writer.Write(json);
            }

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                // check the return status (200 is OK)
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("Bad response - " + response.StatusCode);
                }

                // Process 
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            responseValue = reader.ReadToEnd();
                        }
                    }
                }
            } // end using response


            return RedirectToAction("Products");
        }

        [IgnoreAntiforgeryToken]

        public ActionResult PostTransaction(TransactionDto transaction)
        {
            transaction.TypeCategory = transaction.Quantity > 0 ? "Add" : "Subtract";
            transaction.TransactionId = transaction.TransactionId ?? 0;

            string json = JsonConvert.SerializeObject(transaction);

                
            string EndPoint = "https://localhost:44387/api/v1/transactions/post";
            EndPoint = "https://localhost:44387/api/v1/transactions";
            
            // Test POST syntax

            //EndPoint = "https://webhook.site/02ff76b8-f8fa-42c3-86bc-900241b69ee2";
            HttpClient client = new HttpClient();

            string responseValue = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EndPoint);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Accept = "application/json";

            using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
            {
                writer.Write(json);
            }

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                // check the return status (200 is OK)
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("Bad response - " + response.StatusCode);
                }

                // Process 
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            responseValue = reader.ReadToEnd();
                        }
                    }
                }
            } // end using response


            return RedirectToAction("Transactions");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
