﻿using System;

namespace MvcTest.Models
{
    public class MockProduct
    {
        public int InstanceId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string ProductImageUris { get; set; }
        public string ValidSkus { get; set; }
        public DateTime CreatedTimestamp { get; set; }


        public MockProduct()
        {

        }

        public MockProduct(int instanceId, string name, string desc, string productImageUris, string validSkus, DateTime createdTimeStamp)
        {
            InstanceId = instanceId;
            Name = name;
            Description = desc;
            ProductImageUris = productImageUris;
            ValidSkus = validSkus;
            CreatedTimestamp = createdTimeStamp;
        }

    }
}
