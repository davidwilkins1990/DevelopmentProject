﻿using System;

namespace MvcTest.Models
{
    public class MockProductTransaction
    {
        public int TransactionId { get; set; }

        public int ProductInstanceId { get; set; }

        //public string ItemCode { get; set; }

        //public string Sku { get; set; }

        //public string Brand { get; set; }

        //public string Color { get; set; }

        ////public string UnitOfMeasure { get; set; }

        ////public decimal UnitCost { get; set; }

        //public string ProductLine { get; set; }

        public decimal Quantity { get; set; }

        public DateTime StartedTimestamp { get; set; }
        public DateTime CompletedTimestamp { get; set; }


    }
}
