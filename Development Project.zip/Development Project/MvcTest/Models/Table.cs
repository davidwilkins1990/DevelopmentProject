﻿using System.Data;

namespace MvcTest.Models
{
    public class Table
    {
        public DataTable ResultTable { get; set; }
    }
}
